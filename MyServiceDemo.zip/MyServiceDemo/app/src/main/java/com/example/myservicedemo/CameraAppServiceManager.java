package com.example.myservicedemo;

public class CameraAppServiceManager {

    private static final CameraAppServiceManager CAMERA_APP_SERVICE_MANAGER = new
            CameraAppServiceManager();

    public static CameraAppServiceManager getCameraAppServiceManager() {
        return CAMERA_APP_SERVICE_MANAGER;
    }

    public String getPreviousActiveCamera() {
        return "Rear View Camera";
    }
}
